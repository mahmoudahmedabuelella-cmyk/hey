package com.chess.elite.ui.navigation

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.CompassCalibration
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.chess.elite.ui.board.*
import com.chess.elite.engine.StockfishEngine
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.move.Move

// Global selectable configuration state for Chess customization
object ChessSettings {
    var boardTheme by mutableStateOf(BoardTheme.ClassicWooden)
    var showCoordinates by mutableStateOf(true)
    var defaultDifficulty by mutableStateOf(10) // Skill Level 1 to 20
    var soundEnabled by mutableStateOf(true)
}

// Coordinate conversions
fun toUiSquare(libSquare: com.github.bhlangonijr.chesslib.Square): com.chess.elite.ui.board.Square {
    val name = libSquare.name.lowercase() // e.g. "e4"
    val file = name[0] - 'a'
    val rank = name[1] - '1'
    return com.chess.elite.ui.board.Square(file, rank)
}

fun toLibSquare(uiSquare: com.chess.elite.ui.board.Square): com.github.bhlangonijr.chesslib.Square {
    return com.github.bhlangonijr.chesslib.Square.valueOf(uiSquare.algebraic.uppercase())
}

// Maps chesslib Board pieces model to our boardState dictionary
fun mapBoardToUiState(board: Board): Map<com.chess.elite.ui.board.Square, ChessPiece> {
    val state = mutableMapOf<com.chess.elite.ui.board.Square, ChessPiece>()
    for (file in 0..7) {
        for (rank in 0..7) {
            val algebraic = "${('a' + file)}${rank + 1}".uppercase()
            val libSquare = com.github.bhlangonijr.chesslib.Square.valueOf(algebraic)
            val libPiece = board.getPiece(libSquare)
            if (libPiece != com.github.bhlangonijr.chesslib.Piece.NONE) {
                val color = if (libPiece.pieceSide == Side.WHITE) {
                    PieceColor.WHITE
                } else {
                    PieceColor.BLACK
                }
                val type = when (libPiece.pieceType) {
                    com.github.bhlangonijr.chesslib.PieceType.PAWN -> PieceType.PAWN
                    com.github.bhlangonijr.chesslib.PieceType.KNIGHT -> PieceType.KNIGHT
                    com.github.bhlangonijr.chesslib.PieceType.BISHOP -> PieceType.BISHOP
                    com.github.bhlangonijr.chesslib.PieceType.ROOK -> PieceType.ROOK
                    com.github.bhlangonijr.chesslib.PieceType.QUEEN -> PieceType.QUEEN
                    com.github.bhlangonijr.chesslib.PieceType.KING -> PieceType.KING
                    else -> null
                }
                if (type != null) {
                    state[com.chess.elite.ui.board.Square(file, rank)] = ChessPiece(
                        type = type,
                        color = color,
                        id = "${algebraic}_${libPiece.name}"
                    )
                }
            }
        }
    }
    return state
}

sealed class Screen(val route: String, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Home : Screen("home", "Home", Icons.Default.Home)
    object Play : Screen("play", "Play", Icons.Default.PlayArrow)
    object Puzzles : Screen("puzzles", "Puzzles", Icons.Default.Extension)
    object Analysis : Screen("analysis", "Analysis", Icons.Default.Analytics)
    object Settings : Screen("settings", "Settings", Icons.Default.Settings)
}

@Composable
fun ChessEliteAppNavigation() {
    val navController = rememberNavController()
    val screens = listOf(
        Screen.Home,
        Screen.Play,
        Screen.Puzzles,
        Screen.Analysis,
        Screen.Settings
    )

    Scaffold(
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                screens.forEach { screen ->
                    NavigationBarItem(
                        icon = { Icon(imageVector = screen.icon, contentDescription = screen.title) },
                        label = { Text(text = screen.title, fontSize = 11.sp) },
                        selected = currentRoute == screen.route,
                        onClick = {
                            if (currentRoute != screen.route) {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    onNavigateToPlay = { navController.navigate(Screen.Play.route) },
                    onNavigateToPuzzles = { navController.navigate(Screen.Puzzles.route) }
                )
            }
            composable(Screen.Play.route) {
                PlayScreen()
            }
            composable(Screen.Puzzles.route) {
                PuzzlesScreen()
            }
            composable(Screen.Analysis.route) {
                AnalysisScreen()
            }
            composable(Screen.Settings.route) {
                SettingsScreen()
            }
        }
    }
}

// ============================================
// 1. HOME SCREEN (DYNAMIC DASHBOARD)
// ============================================
@Composable
fun HomeScreen(onNavigateToPlay: () -> Unit, onNavigateToPuzzles: () -> Unit) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121214))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF1E1E24))
                    .padding(24.dp)
            ) {
                Column {
                    Text(
                        text = "Chess Elite Club 🏆",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Experience master-level local chess engine, interactive puzzles & custom diagnostics.",
                        fontSize = 13.sp,
                        color = Color.LightGray
                    )
                }
            }
        }

        // Stats section
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E24)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Your Progress Stats",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("ELO Rating", fontSize = 11.sp, color = Color.Gray)
                            Text("1450", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF4CAF50))
                        }
                        Column {
                            Text("Puzzles Solved", fontSize = 11.sp, color = Color.Gray)
                            Text("124", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFC107))
                        }
                        Column {
                            Text("Matches vs AI", fontSize = 11.sp, color = Color.Gray)
                            Text("36 - 12", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2196F3))
                        }
                    }
                }
            }
        }

        // Quick action grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    onClick = onNavigateToPlay,
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1F2937)),
                    modifier = Modifier.weight(1f).height(120.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(16.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFF4CAF50), modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Vs Computer AI", fontWeight = FontWeight.SemiBold, color = Color.White, fontSize = 14.sp)
                    }
                }

                Card(
                    onClick = onNavigateToPuzzles,
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1F2937)),
                    modifier = Modifier.weight(1f).height(120.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(16.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.Extension, contentDescription = null, tint = Color(0xFFFFC107), modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Solve Puzzles", fontWeight = FontWeight.SemiBold, color = Color.White, fontSize = 14.sp)
                    }
                }
            }
        }

        // General Information
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E24)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Tips",
                        tint = Color(0xFF818CF8),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Tip: You can customize board themes and coordinates visual configurations inside the Settings screen at any time!",
                        fontSize = 12.sp,
                        color = Color.LightGray,
                        lineHeight = 16.sp,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

// ============================================
// 2. PLAY SCREEN (AI VS PLAYER & PASS AND PLAY)
// ============================================
@Composable
fun PlayScreen() {
    val context = LocalContext.current
    var gameMode by remember { mutableStateOf("vs_ai") } // "vs_ai" or "pass_and_play"
    
    // Core Chess engine board
    val board = remember { Board() }
    var boardState by remember { mutableStateOf(mapBoardToUiState(board)) }
    var selectedSquare by remember { mutableStateOf<com.chess.elite.ui.board.Square?>(null) }
    var legalMoves by remember { mutableStateOf<List<com.chess.elite.ui.board.Square>>(emptyList()) }
    var lastMove by remember { mutableStateOf<Pair<com.chess.elite.ui.board.Square, com.chess.elite.ui.board.Square>?>(null) }
    var moveHistory by remember { mutableStateOf<List<String>>(emptyList()) }
    var isFlipped by remember { mutableStateOf(false) }
    var gameOverMessage by remember { mutableStateOf<String?>(null) }
    var isCalculatingAi by remember { mutableStateOf(false) }

    // Stockfish engine
    val engine = remember { StockfishEngine(context) }

    val coroutineScope = rememberCoroutineScope()

    // Initialize/Start & Release Stockfish UCI process correctly
    LaunchedEffect(engine) {
        engine.start()
        engine.configureEngine(skillLevel = ChessSettings.defaultDifficulty)
    }

    DisposableEffect(engine) {
        onDispose {
            engine.stop()
        }
    }

    // Capture engine best move outputs and stream to local gameplay state
    LaunchedEffect(engine) {
        engine.engineOutputs.collect { response ->
            when (response) {
                is StockfishEngine.EngineResponse.BestMove -> {
                    val moveStr = response.move
                    if (moveStr.length >= 4) {
                        val fromName = moveStr.substring(0, 2).uppercase()
                        val toName = moveStr.substring(2, 4).uppercase()

                        try {
                            val fromLib = com.github.bhlangonijr.chesslib.Square.valueOf(fromName)
                            val toLib = com.github.bhlangonijr.chesslib.Square.valueOf(toName)

                            val matches = board.legalMoves().filter { it.from == fromLib && it.to == toLib }
                            if (matches.isNotEmpty()) {
                                board.doMove(matches.first())

                                val fromUi = toUiSquare(fromLib)
                                val toUi = toUiSquare(toLib)

                                // Refresh Game status
                                boardState = mapBoardToUiState(board)
                                lastMove = Pair(fromUi, toUi)
                                moveHistory = board.history.map { it.toString() }

                                if (board.isMated) {
                                    gameOverMessage = "Checkmate! Black wins! 🤖"
                                } else if (board.isDraw) {
                                    gameOverMessage = "Draw Match! 🤝"
                                }
                            }
                        } catch (e: Exception) {
                            // Safe catch on parsing error
                        }
                    }
                    isCalculatingAi = false
                }
                else -> {}
            }
        }
    }

    fun makeMove(from: com.chess.elite.ui.board.Square, to: com.chess.elite.ui.board.Square) {
        val libFrom = toLibSquare(from)
        val libTo = toLibSquare(to)
        val matches = board.legalMoves().filter { it.from == libFrom && it.to == libTo }

        if (matches.isNotEmpty()) {
            board.doMove(matches.first())
            boardState = mapBoardToUiState(board)
            lastMove = Pair(from, to)
            selectedSquare = null
            legalMoves = emptyList()
            moveHistory = board.history.map { it.toString() }

            if (board.isMated) {
                gameOverMessage = "Checkmate! ${if (board.sideToMove == Side.WHITE) "Black" else "White"} wins! 🏆"
            } else if (board.isDraw) {
                gameOverMessage = "Draw Match! 🤝"
            } else {
                // Trigger computer decision if Vs Engine is configured
                if (gameMode == "vs_ai" && board.sideToMove == Side.BLACK) {
                    isCalculatingAi = true
                    engine.analyzePosition(board.fen, searchTimeMs = 800)
                }
            }
        } else {
            selectedSquare = null
            legalMoves = emptyList()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121214))
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Selector for Game Mode
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF1E1E24)),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Text(
                text = "Vs Computer AI",
                color = if (gameMode == "vs_ai") Color(0xFF4CAF50) else Color.Gray,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                modifier = Modifier
                    .weight(1f)
                    .clickable { gameMode = "vs_ai" }
                    .padding(12.dp),
                textAlign = TextAlign.Center
            )
            Divider(modifier = Modifier.width(1.dp).fillMaxHeight().background(Color.DarkGray))
            Text(
                text = "Pass & Play",
                color = if (gameMode == "pass_and_play") Color(0xFF4CAF50) else Color.Gray,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                modifier = Modifier
                    .weight(1f)
                    .clickable { gameMode = "pass_and_play" }
                    .padding(12.dp),
                textAlign = TextAlign.Center
            )
        }

        // Active State HUD
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val playerLabel = if (board.sideToMove == Side.WHITE) {
                "White's Turn 🏳️"
            } else {
                if (gameMode == "vs_ai") "Thinking AI... 🤖" else "Black's Turn 🏴"
            }
            Text(
                text = playerLabel,
                fontSize = 16.sp,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )

            Button(
                onClick = { isFlipped = !isFlipped },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E3440)),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Flip Board 🔃", fontSize = 11.sp, color = Color.White)
            }
        }

        // Animated Interactive Graphical Chessboard
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(12.dp))
                .border(2.dp, Color(0xFF333333), RoundedCornerShape(12.dp))
        ) {
            ChessBoard(
                boardState = boardState,
                legalMoves = legalMoves,
                lastMove = lastMove,
                arrows = emptyList(),
                onMoveRequested = { from, to -> makeMove(from, to) },
                onSquareSelected = { sq ->
                    if (gameOverMessage != null || isCalculatingAi) return@ChessBoard

                    if (selectedSquare == sq) {
                        selectedSquare = null
                        legalMoves = emptyList()
                    } else if (selectedSquare == null) {
                        val piece = boardState[sq]
                        val rightColorToMove = piece != null && (
                            (piece.color == PieceColor.WHITE && board.sideToMove == Side.WHITE) ||
                            (piece.color == PieceColor.BLACK && board.sideToMove == Side.BLACK)
                        )
                        if (rightColorToMove) {
                            selectedSquare = sq
                            val libCurrentSquare = toLibSquare(sq)
                            legalMoves = board.legalMoves()
                                .filter { it.from == libCurrentSquare }
                                .map { toUiSquare(it.to) }
                        }
                    } else {
                        if (legalMoves.contains(sq)) {
                            makeMove(selectedSquare!!, sq)
                        } else {
                            val piece = boardState[sq]
                            val rightColorToMove = piece != null && (
                                (piece.color == PieceColor.WHITE && board.sideToMove == Side.WHITE) ||
                                (piece.color == PieceColor.BLACK && board.sideToMove == Side.BLACK)
                            )
                            if (rightColorToMove) {
                                selectedSquare = sq
                                val libCurrentSquare = toLibSquare(sq)
                                legalMoves = board.legalMoves()
                                    .filter { it.from == libCurrentSquare }
                                    .map { toUiSquare(it.to) }
                            } else {
                                selectedSquare = null
                                legalMoves = emptyList()
                            }
                        }
                    }
                },
                selectedSquare = selectedSquare,
                isFlipped = isFlipped,
                boardTheme = ChessSettings.boardTheme,
                showCoordinates = ChessSettings.showCoordinates
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Match history, undo actions & feedback
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = {
                    board.clear()
                    board.loadFromFen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")
                    boardState = mapBoardToUiState(board)
                    lastMove = null
                    selectedSquare = null
                    legalMoves = emptyList()
                    moveHistory = emptyList()
                    gameOverMessage = null
                    isCalculatingAi = false
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC92A2A)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Reset Game 🔄", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = {
                    // Quick undo of last 2 moves if VS AI, or 1 move if Pass & Play
                    val historyCount = board.history.size
                    if (historyCount > 0) {
                        val undoSteps = if (gameMode == "vs_ai" && historyCount >= 2) 2 else 1
                        for (i in 1..undoSteps) {
                            board.undoMove()
                        }
                        boardState = mapBoardToUiState(board)
                        lastMove = null
                        selectedSquare = null
                        legalMoves = emptyList()
                        moveHistory = board.history.map { it.toString() }
                        gameOverMessage = null
                        isCalculatingAi = false
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2B8A3E)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Take Back ↩️", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Game Over notification HUD modal
        gameOverMessage?.let { msg ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF25262B)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(2.dp, Color(0xFF4CAF50), RoundedCornerShape(12.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(msg, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                        onClick = {
                            board.clear()
                            board.loadFromFen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")
                            boardState = mapBoardToUiState(board)
                            lastMove = null
                            selectedSquare = null
                            legalMoves = emptyList()
                            moveHistory = emptyList()
                            gameOverMessage = null
                        }
                    ) {
                        Text("Start Again! 🏆", color = Color.White)
                    }
                }
            }
        }

        // Live Moves tracker column underneath the board
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E24)),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(top = 12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "Live Match Move Log (${moveHistory.size})",
                    fontSize = 12.sp,
                    color = Color.LightGray,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    val groupedMoves = moveHistory.chunked(2)
                    items(groupedMoves) { turn ->
                        val turnIdx = moveHistory.indexOf(turn[0]) / 2 + 1
                        val blackMove = if (turn.size > 1) turn[1] else ""
                        Text(
                            text = "Turn $turnIdx.  White: ${turn[0]}     Black: $blackMove",
                            fontSize = 13.sp,
                            color = Color.White,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

// ============================================
// 3. PUZZLES SCREEN (TACTICAL CHESS MISSIONS)
// ============================================
data class LivePuzzle(
    val id: String,
    val title: String,
    val description: String,
    val fen: String,
    val solution: List<String>,
    val difficulty: String,
    val source: String
)

val LocalPuzzleStore = listOf(
    LivePuzzle("1", "Anastasia's Mate 🧩", "Attack of White. Sacrifice Queen for dynamic checkmate.", "r1b2r1k/pp4pp/2p5/1p1pn3/8/5P2/P1P1R1PP/R1B3K1 w - - 0 1", listOf("e2e5"), "Easy", "Lichess"),
    LivePuzzle("2", "Castle Assault 🏰", "Smash the weak fortress on row 8.", "6k1/5ppp/8/8/8/8/8/3R2K1 w - - 0 1", listOf("d1d8"), "Easy", "Lichess"),
    LivePuzzle("3", "Royal Fork Strategy 🍴", "Attack King and Queen at the same time with the knight.", "q3k3/8/8/3N4/8/8/8/4K3 w - - 0 1", listOf("d5c7"), "Medium", "Lichess"),
    LivePuzzle("4", "The Golden Diagonal ♗", "Move Bishop to capture adversary high defense values.", "r3k3/8/8/2B5/8/8/8/4K2R w K - 0 1", listOf("c5b6"), "Medium", "Lichess")
)

@Composable
fun PuzzlesScreen() {
    var activeIdx by remember { mutableStateOf(0) }
    val puzzle = LocalPuzzleStore[activeIdx]

    val board = remember(activeIdx) { Board() }
    
    // Set current puzzle position
    LaunchedEffect(activeIdx) {
        board.clear()
        board.loadFromFen(puzzle.fen)
    }

    var boardState by remember(activeIdx) { mutableStateOf(mapBoardToUiState(board)) }
    var selectedSquare by remember { mutableStateOf<com.chess.elite.ui.board.Square?>(null) }
    var legalMoves by remember { mutableStateOf<List<com.chess.elite.ui.board.Square>>(emptyList()) }
    var lastMove by remember { mutableStateOf<Pair<com.chess.elite.ui.board.Square, com.chess.elite.ui.board.Square>?>(null) }
    var successHUD by remember { mutableStateOf(false) }
    var errorHUD by remember { mutableStateOf(false) }

    fun executePuzzleMove(from: com.chess.elite.ui.board.Square, to: com.chess.elite.ui.board.Square) {
        val uciMove = "${from.algebraic}${to.algebraic}"
        val targetSolution = puzzle.solution.firstOrNull() // Simplify checklist match to first move

        if (uciMove.lowercase() == targetSolution?.lowercase()) {
            // Puzzle solved!
            val libFrom = toLibSquare(from)
            val libTo = toLibSquare(to)
            val matches = board.legalMoves().filter { it.from == libFrom && it.to == libTo }
            if (matches.isNotEmpty()) {
                board.doMove(matches.first())
            }
            boardState = mapBoardToUiState(board)
            lastMove = Pair(from, to)
            successHUD = true
            errorHUD = false
        } else {
            errorHUD = true
            successHUD = false
        }
        selectedSquare = null
        legalMoves = emptyList()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121214))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Puzzle state title cards
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF1E1E24))
                .padding(16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Puzzle #${activeIdx + 1}: ${puzzle.title}",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Badge(containerColor = Color(0xFFFFC107)) {
                        Text(puzzle.difficulty, color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = puzzle.description,
                    fontSize = 12.sp,
                    color = Color.LightGray
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Chessboard
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(12.dp))
                .border(2.dp, Color(0xFF333333), RoundedCornerShape(12.dp))
        ) {
            ChessBoard(
                boardState = boardState,
                legalMoves = legalMoves,
                lastMove = lastMove,
                arrows = emptyList(),
                onMoveRequested = { from, to -> executePuzzleMove(from, to) },
                onSquareSelected = { sq ->
                    if (successHUD) return@ChessBoard

                    if (selectedSquare == sq) {
                        selectedSquare = null
                        legalMoves = emptyList()
                    } else if (selectedSquare == null) {
                        val piece = boardState[sq]
                        val rightColorToMove = piece != null && (
                            (piece.color == PieceColor.WHITE && board.sideToMove == Side.WHITE) ||
                            (piece.color == PieceColor.BLACK && board.sideToMove == Side.BLACK)
                        )
                        if (rightColorToMove) {
                            selectedSquare = sq
                            val libCurrentSquare = toLibSquare(sq)
                            legalMoves = board.legalMoves()
                                .filter { it.from == libCurrentSquare }
                                .map { toUiSquare(it.to) }
                        }
                    } else {
                        if (legalMoves.contains(sq)) {
                            executePuzzleMove(selectedSquare!!, sq)
                        } else {
                            val piece = boardState[sq]
                            val rightColorToMove = piece != null && (
                                (piece.color == PieceColor.WHITE && board.sideToMove == Side.WHITE) ||
                                (piece.color == PieceColor.BLACK && board.sideToMove == Side.BLACK)
                            )
                            if (rightColorToMove) {
                                selectedSquare = sq
                                val libCurrentSquare = toLibSquare(sq)
                                legalMoves = board.legalMoves()
                                    .filter { it.from == libCurrentSquare }
                                    .map { toUiSquare(it.to) }
                            } else {
                                selectedSquare = null
                                legalMoves = emptyList()
                            }
                        }
                    }
                },
                selectedSquare = selectedSquare,
                isFlipped = false,
                boardTheme = ChessSettings.boardTheme,
                showCoordinates = ChessSettings.showCoordinates
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Success / Mismatch overlays
        if (successHUD) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF2B8A3E))
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Excellent! Solved! 🎉", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Button(
                    onClick = {
                        successHUD = false
                        errorHUD = false
                        lastMove = null
                        selectedSquare = null
                        legalMoves = emptyList()
                        activeIdx = (activeIdx + 1) % LocalPuzzleStore.size
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White)
                ) {
                    Text("Next Puzzle ➡️", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        } else if (errorHUD) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFC92A2A))
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Inaccurate move, try again! ❌", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Button(
                    onClick = {
                        // Reset current position
                        board.clear()
                        board.loadFromFen(puzzle.fen)
                        boardState = mapBoardToUiState(board)
                        lastMove = null
                        selectedSquare = null
                        legalMoves = emptyList()
                        errorHUD = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White)
                ) {
                    Text("Retry 🔄", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        } else {
            // Assistance
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF1E1E24))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Lightbulb, contentDescription = null, tint = Color(0xFFFFC107), modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Figure out the correct master chess move in the shown layout! Touch and move the units.",
                    fontSize = 11.sp,
                    color = Color.LightGray
                )
            }
        }
    }
}

// ============================================
// 4. ANALYSIS SCREEN (POSITION EVALUATOR)
// ============================================
@Composable
fun AnalysisScreen() {
    val context = LocalContext.current
    val board = remember { Board() }
    var boardState by remember { mutableStateOf(mapBoardToUiState(board)) }
    var selectedSquare by remember { mutableStateOf<com.chess.elite.ui.board.Square?>(null) }
    var legalMoves by remember { mutableStateOf<List<com.chess.elite.ui.board.Square>>(emptyList()) }
    var lastMove by remember { mutableStateOf<Pair<com.chess.elite.ui.board.Square, com.chess.elite.ui.board.Square>?>(null) }
    var evaluationValue by remember { mutableStateOf("0.00") }
    var calculatedLine by remember { mutableStateOf("Click Stockfish to evaluate") }
    var loadingEval by remember { mutableStateOf(false) }

    val engine = remember { StockfishEngine(context) }

    LaunchedEffect(engine) {
        engine.start()
    }

    DisposableEffect(engine) {
        onDispose {
            engine.stop()
        }
    }

    LaunchedEffect(engine) {
        engine.engineOutputs.collect { response ->
            when (response) {
                is StockfishEngine.EngineResponse.Info -> {
                    if (response.centipawns != null) {
                        val scoreValue = response.centipawns / 100.0
                        val rawLabel = if (scoreValue >= 0) "+${String.format("%.2f", scoreValue)}" else String.format("%.2f", scoreValue)
                        evaluationValue = rawLabel
                    } else if (response.mateInMoves != null) {
                        evaluationValue = "M${response.mateInMoves}"
                    }
                    if (response.bestLine != null && response.bestLine.isNotEmpty()) {
                        calculatedLine = "Best Line: " + response.bestLine.take(5).joinToString(" ")
                    }
                    loadingEval = false
                }
                else -> {}
            }
        }
    }

    fun executeAnalysisMove(from: com.chess.elite.ui.board.Square, to: com.chess.elite.ui.board.Square) {
        val libFrom = toLibSquare(from)
        val libTo = toLibSquare(to)
        val matches = board.legalMoves().filter { it.from == libFrom && it.to == libTo }

        if (matches.isNotEmpty()) {
            board.doMove(matches.first())
            boardState = mapBoardToUiState(board)
            lastMove = Pair(from, to)
            selectedSquare = null
            legalMoves = emptyList()
        } else {
            selectedSquare = null
            legalMoves = emptyList()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121214))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Core diagnostic header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF1E1E24))
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Stockfish 18 Engine Diagnostics ⚙️", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(2.dp))
                Text(calculatedLine, color = Color.LightGray, fontSize = 11.sp, maxLines = 1)
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF2E3440))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = if (loadingEval) "Calculing..." else evaluationValue,
                    color = if (evaluationValue.startsWith("-")) Color(0xFFE57373) else Color(0xFF81C784),
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }

        // Chessboard
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(12.dp))
                .border(2.dp, Color(0xFF333333), RoundedCornerShape(12.dp))
        ) {
            ChessBoard(
                boardState = boardState,
                legalMoves = legalMoves,
                lastMove = lastMove,
                arrows = emptyList(),
                onMoveRequested = { from, to -> executeAnalysisMove(from, to) },
                onSquareSelected = { sq ->
                    if (selectedSquare == sq) {
                        selectedSquare = null
                        legalMoves = emptyList()
                    } else if (selectedSquare == null) {
                        val piece = boardState[sq]
                        val rightColorToMove = piece != null && (
                            (piece.color == PieceColor.WHITE && board.sideToMove == Side.WHITE) ||
                            (piece.color == PieceColor.BLACK && board.sideToMove == Side.BLACK)
                        )
                        if (rightColorToMove) {
                            selectedSquare = sq
                            val libCurrentSquare = toLibSquare(sq)
                            legalMoves = board.legalMoves()
                                .filter { it.from == libCurrentSquare }
                                .map { toUiSquare(it.to) }
                        }
                    } else {
                        if (legalMoves.contains(sq)) {
                            executeAnalysisMove(selectedSquare!!, sq)
                        } else {
                            val piece = boardState[sq]
                            val rightColorToMove = piece != null && (
                                (piece.color == PieceColor.WHITE && board.sideToMove == Side.WHITE) ||
                                (piece.color == PieceColor.BLACK && board.sideToMove == Side.BLACK)
                            )
                            if (rightColorToMove) {
                                selectedSquare = sq
                                val libCurrentSquare = toLibSquare(sq)
                                legalMoves = board.legalMoves()
                                    .filter { it.from == libCurrentSquare }
                                    .map { toUiSquare(it.to) }
                            } else {
                                selectedSquare = null
                                legalMoves = emptyList()
                            }
                        }
                    }
                },
                selectedSquare = selectedSquare,
                isFlipped = false,
                boardTheme = ChessSettings.boardTheme,
                showCoordinates = ChessSettings.showCoordinates
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Diagnostic action loops
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = {
                    loadingEval = true
                    engine.analyzePosition(board.fen, searchTimeMs = 1500)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                modifier = Modifier.weight(1.5f),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Analyze Position 🧠", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }

            Button(
                onClick = {
                    board.clear()
                    board.loadFromFen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")
                    boardState = mapBoardToUiState(board)
                    lastMove = null
                    selectedSquare = null
                    legalMoves = emptyList()
                    evaluationValue = "0.00"
                    calculatedLine = "Click Stockfish to evaluate"
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E1E24)),
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Reset Position", color = Color.LightGray, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Active layout values descriptor
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E24)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Standard state fen string 📝", color = Color.Gray, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(4.dp))
                SelectionContainer {
                    Text(board.fen, color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

// Wrap for clipboard FEN selection
@Composable
fun SelectionContainer(content: @Composable () -> Unit) {
    Box(modifier = Modifier.clickable {  }) {
        content()
    }
}

// ============================================
// 5. SETTINGS SCREEN (BOARD THEMES & VISUALS)
// ============================================
@Composable
fun SettingsScreen() {
    val themes = listOf(
        BoardTheme.ClassicWooden,
        BoardTheme.TournamentGreen,
        BoardTheme.CosmicMidnight
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121214))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App settings visual title
        item {
            Text(
                text = "Styling & System Configurations ⚙️",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        // Active Chessboard Themes Selector
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E24)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Customize Board Theme Style",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    themes.forEach { theme ->
                        val isSelected = ChessSettings.boardTheme.id == theme.id
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) Color(0xFF1F2937) else Color.Transparent)
                                .clickable { ChessSettings.boardTheme = theme }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Little colored square preview blocks
                            Row(modifier = Modifier.size(36.dp).clip(RoundedCornerShape(4.dp))) {
                                Box(modifier = Modifier.weight(1f).fillMaxHeight().background(theme.lightSquareColor))
                                Box(modifier = Modifier.weight(1f).fillMaxHeight().background(theme.darkSquareColor))
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(
                                text = theme.name,
                                fontSize = 14.sp,
                                color = if (isSelected) Color(0xFF4CAF50) else Color.White,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.weight(1f)
                            )
                            if (isSelected) {
                                Icon(Icons.Default.Star, contentDescription = "Active", tint = Color(0xFFFFC107))
                            }
                        }
                    }
                }
            }
        }

        // Play options settings card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E24)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Visual and Audio Settings",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // Coordinates visibility setting
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Show Board Coordinates", color = Color.White, fontSize = 13.sp)
                            Text("Renders alphanumeric borders (a-h, 1-8)", color = Color.Gray, fontSize = 11.sp)
                        }
                        Switch(
                            checked = ChessSettings.showCoordinates,
                            onCheckedChange = { ChessSettings.showCoordinates = it }
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Move sounds setting
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Enable Sound FX", color = Color.White, fontSize = 13.sp)
                            Text("Play tick noise upon valid move", color = Color.Gray, fontSize = 11.sp)
                        }
                        Switch(
                            checked = ChessSettings.soundEnabled,
                            onCheckedChange = { ChessSettings.soundEnabled = it }
                        )
                    }
                }
            }
        }

        // Engine configuration card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E24)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Stockfish level of difficulty",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Current: Level ${ChessSettings.defaultDifficulty}",
                        color = Color.LightGray,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Slider(
                        value = ChessSettings.defaultDifficulty.toFloat(),
                        onValueChange = { ChessSettings.defaultDifficulty = it.toInt() },
                        valueRange = 1f..20f,
                        steps = 18
                    )
                }
            }
        }
    }
}
