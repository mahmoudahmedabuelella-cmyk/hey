package com.chess.elite.ui.board

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

data class Square(val file: Int, val rank: Int) {
    // Translates Chess piece board coordinates e.g., (0,0) is A1 -> H8.
    val algebraic: String
        get() = "${('a' + file)}${rank + 1}"
}

enum class PieceType { PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING }
enum class PieceColor { WHITE, BLACK }
data class ChessPiece(val type: PieceType, val color: PieceColor, val id: String)

// Configurable Color themes for Board Style customization
data class BoardTheme(
    val id: String,
    val name: String,
    val lightSquareColor: Color,
    val darkSquareColor: Color,
    val highlightColor: Color,
    val targetSuggestionColor: Color
) {
    companion object {
        val ClassicWooden = BoardTheme(
            id = "classic_wood",
            name = "Classic Walnut",
            lightSquareColor = Color(0xFFF0D9B5),
            darkSquareColor = Color(0xFFB58863),
            highlightColor = Color(0x7FBCB73E),
            targetSuggestionColor = Color(0x55119911)
        )
        val TournamentGreen = BoardTheme(
            id = "tourney_green",
            name = "Tournament",
            lightSquareColor = Color(0xFFEEEEEE),
            darkSquareColor = Color(0xFF769656),
            highlightColor = Color(0x7FB9D34F),
            targetSuggestionColor = Color(0x660055DD)
        )
        val CosmicMidnight = BoardTheme(
            id = "cosmic_midnight",
            name = "Cosmic Sky",
            lightSquareColor = Color(0xFF2E3440),
            darkSquareColor = Color(0xFF434C5E),
            highlightColor = Color(0x9E88C0D0),
            targetSuggestionColor = Color(0x665E81AC)
        )
    }
}

/**
 * Animated High Fidelity Chessboard Composable.
 * Features:
 * - Tap to select / Move matching
 * - Real Drag and Drop support
 * - Coordinates indicators (Files/Ranks)
 * - Move indicators (highlights, legal targets, arrow path lines)
 * - Piece flip transition toggle
 * - Animation speed factor adjustment
 */
@Composable
fun ChessBoard(
    boardState: Map<Square, ChessPiece>,
    legalMoves: List<Square>,
    lastMove: Pair<Square, Square>?,
    arrows: List<Pair<Square, Square>>,
    onMoveRequested: (from: Square, to: Square) -> Unit,
    onSquareSelected: (Square) -> Unit,
    selectedSquare: Square?,
    isFlipped: Boolean = false,
    boardTheme: BoardTheme = BoardTheme.ClassicWooden,
    showCoordinates: Boolean = true,
    animationSpeedMs: Int = 200,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    
    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .background(boardTheme.darkSquareColor)
    ) {
        val widthPx = constraints.maxWidth.toFloat()
        val squareSizePx = widthPx / 8f
        val squareSizeDp = with(LocalDensity.current) { squareSizePx.toDp() }

        // Track dragging states dynamically
        var draggingPiece by remember { mutableStateOf<ChessPiece?>(null) }
        var draggingFromSquare by remember { mutableStateOf<Square?>(null) }
        var dragOffset by remember { mutableStateOf(Offset.Zero) }

        // Store active moving animations of each chess piece on the board
        val pieceOffsets = remember { mutableStateMapOf<String, Animatable<Offset, *>>() }

        // Apply smooth visual slide animation coordinates on board state refresh
        LaunchedEffect(boardState) {
            boardState.forEach { (sq, piece) ->
                val targetScreenOffset = boardSquareToOffset(sq, squareSizePx, isFlipped)
                val animator = pieceOffsets.getOrPut(piece.id) {
                    Animatable(targetScreenOffset, Offset.VectorConverter)
                }
                coroutineScope.launch {
                    animator.animateTo(
                        targetValue = targetScreenOffset,
                        animationSpec = tween(durationMillis = animationSpeedMs)
                    )
                }
            }
        }

        // Draw Squares Grid Base
        Canvas(modifier = Modifier.fillMaxSize()) {
            for (file in 0..7) {
                for (rank in 0..7) {
                    // Alternate row square paint matching algebraic chessboard layouts
                    val isLight = (file + rank) % 2 != 0
                    val left = file * squareSizePx
                    val top = rank * squareSizePx
                    
                    drawRect(
                        color = if (isLight) boardTheme.lightSquareColor else boardTheme.darkSquareColor,
                        topLeft = Offset(left, top),
                        size = Size(squareSizePx, squareSizePx)
                    )
                }
            }

            // Draw Last Move highlight paths
            lastMove?.let { (from, to) ->
                val fromOffset = boardSquareToOffset(from, squareSizePx, isFlipped)
                val toOffset = boardSquareToOffset(to, squareSizePx, isFlipped)
                
                drawRect(
                    color = boardTheme.highlightColor,
                    topLeft = fromOffset,
                    size = Size(squareSizePx, squareSizePx)
                )
                drawRect(
                    color = boardTheme.highlightColor,
                    topLeft = toOffset,
                    size = Size(squareSizePx, squareSizePx)
                )
            }
        }

        // Interaction Gesture overlay to capture dragging and clicking smoothly
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(isFlipped, boardState) {
                    detectTapGestures(
                        onTap = { tapOffset ->
                            val sq = offsetToBoardSquare(tapOffset, squareSizePx, isFlipped)
                            onSquareSelected(sq)
                        }
                    )
                }
                .pointerInput(isFlipped, boardState) {
                    detectDragGestures(
                        onDragStart = { startOffset ->
                            val sq = offsetToBoardSquare(startOffset, squareSizePx, isFlipped)
                            val piece = boardState[sq]
                            if (piece != null) {
                                draggingPiece = piece
                                draggingFromSquare = sq
                                dragOffset = Offset.Zero
                            }
                        },
                        onDragEnd = {
                            val from = draggingFromSquare
                            val piece = draggingPiece
                            if (from != null && piece != null) {
                                val destinationOffset = boardSquareToOffset(from, squareSizePx, isFlipped) + dragOffset
                                val toSquare = offsetToBoardSquare(destinationOffset, squareSizePx, isFlipped)
                                
                                // Clean boundary check and fire move block
                                if (toSquare.file in 0..7 && toSquare.rank in 0..7 && toSquare != from) {
                                    onMoveRequested(from, toSquare)
                                }
                            }
                            draggingPiece = null
                            draggingFromSquare = null
                            dragOffset = Offset.Zero
                        },
                        onDragCancel = {
                            draggingPiece = null
                            draggingFromSquare = null
                            dragOffset = Offset.Zero
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            dragOffset += dragAmount
                        }
                    )
                }
        ) {
            // Draw Coordinates labels if enabled in configuration
            if (showCoordinates) {
                CoordinatesOverlay(isFlipped, boardTheme)
            }

            // Draw Legal Moves highlights as simple visual dots or circles
            legalMoves.forEach { targetSq ->
                val offset = boardSquareToOffset(targetSq, squareSizePx, isFlipped)
                val isOccupied = boardState.containsKey(targetSq)
                
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val center = offset + Offset(squareSizePx / 2f, squareSizePx / 2f)
                        if (isOccupied) {
                            // Target captured preview: outer circle border
                            drawCircle(
                                color = boardTheme.targetSuggestionColor,
                                radius = squareSizePx / 2.3f,
                                center = center,
                                style = Stroke(width = 4.dp.toPx())
                            )
                        } else {
                            // Empty path suggestion: solid dot in center
                            drawCircle(
                                color = boardTheme.targetSuggestionColor,
                                radius = squareSizePx / 6f,
                                center = center
                            )
                        }
                    }
                }
            }

            // Render and position all stationary and animated chess pieces
            boardState.forEach { (square, piece) ->
                val isDraggingThis = draggingPiece?.id == piece.id
                val finalOffset = if (isDraggingThis) {
                    boardSquareToOffset(square, squareSizePx, isFlipped) + dragOffset
                } else {
                    pieceOffsets[piece.id]?.value ?: boardSquareToOffset(square, squareSizePx, isFlipped)
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                ) {
                    PieceRenderer(
                        piece = piece,
                        sizePx = squareSizePx,
                        offset = finalOffset,
                        isDragging = isDraggingThis
                    )
                }
            }

            // Draw Tactical Analysis Vectors & Arrows on canvas overlays
            Canvas(modifier = Modifier.fillMaxSize()) {
                arrows.forEach { (from, to) ->
                    val start = boardSquareToOffset(from, squareSizePx, isFlipped) + Offset(squareSizePx/2f, squareSizePx/2f)
                    val end = boardSquareToOffset(to, squareSizePx, isFlipped) + Offset(squareSizePx/2f, squareSizePx/2f)
                    
                    // Main stem stroke line
                    drawLine(
                        color = Color(0xAAFF3333),
                        start = start,
                        end = end,
                        strokeWidth = 6.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                    
                    // Arrow header cap
                    val direction = (end - start)
                    val length = direction.getDistance()
                    if (length > 10f) {
                        val arrowLength = 15.dp.toPx()
                        val unitDirection = direction / length
                        val rightWing = Offset(-unitDirection.y, unitDirection.x) * (arrowLength * 0.5f) - (unitDirection * arrowLength)
                        val leftWing = Offset(unitDirection.y, -unitDirection.x) * (arrowLength * 0.5f) - (unitDirection * arrowLength)
                        
                        drawLine(
                            color = Color(0xAAFF3333),
                            start = end,
                            end = end + rightWing,
                            strokeWidth = 6.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                        drawLine(
                            color = Color(0xAAFF3333),
                            start = end,
                            end = end + leftWing,
                            strokeWidth = 6.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }
                }
            }
        }
    }
}

/**
 * Draws coordinate labels (a-h for files, 1-8 for ranks) around the board edges.
 */
@Composable
private fun CoordinatesOverlay(isFlipped: Boolean, theme: BoardTheme) {
    Box(modifier = Modifier.fillMaxSize()) {
        val textColorOnDark = theme.lightSquareColor
        val textColorOnLight = theme.darkSquareColor

        // Ranks indicators (1-8) along left rail
        Column(
            modifier = Modifier.fillMaxHeight().padding(start = 3.dp),
            // reverse the sorting matching the orientation
            verticalArrangement = if (isFlipped) androidx.compose.foundation.layout.Arrangement.Top else androidx.compose.foundation.layout.Arrangement.Bottom
        ) {
            val ranks = if (isFlipped) 0..7 else 7 downTo 0
            for (rank in ranks) {
                val label = (rank + 1).toString()
                val isLightSquareInCol_A = rank % 2 == 0 // Column A alternates ranks
                Box(
                    modifier = Modifier.weight(1f),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isLightSquareInCol_A) textColorOnLight else textColorOnDark,
                        textAlign = TextAlign.Start
                    )
                }
            }
        }

        // Files indicators (a-h) along bottom rail
        Row(
            modifier = Modifier.fillMaxWidth().align(Alignment.BottomEnd).padding(bottom = 2.dp),
            horizontalArrangement = if (isFlipped) Arrangement_Reverse() else Arrangement_Normal()
        ) {
            val files = if (isFlipped) (7 downTo 0) else (0..7)
            for (file in files) {
                val label = ('a' + file).toString()
                val isLightSquareInRow_1 = file % 2 != 0 // Row 1 is black on a1 (0), light on b1 (1)
                Box(
                    modifier = Modifier.weight(1f),
                    contentAlignment = Alignment.BottomEnd
                ) {
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isLightSquareInRow_1) textColorOnLight else textColorOnDark,
                        textAlign = TextAlign.End,
                        modifier = Modifier.padding(end = 4.dp)
                    )
                }
            }
        }
    }
}

// Visual asset vector piece drawers.
// This matches standard chess symbol sets dynamically, or falls back to Unicode for stability
@Composable
private fun PieceRenderer(
    piece: ChessPiece,
    sizePx: Float,
    offset: Offset,
    isDragging: Boolean
) {
    val density = LocalDensity.current
    val sizeDp = with(density) { sizePx.toDp() }
    
    val unicodeChar = when (piece.color) {
        PieceColor.WHITE -> when (piece.type) {
            PieceType.PAWN -> "♙"
            PieceType.KNIGHT -> "♘"
            PieceType.BISHOP -> "♗"
            PieceType.ROOK -> "♖"
            PieceType.QUEEN -> "♕"
            PieceType.KING -> "♔"
        }
        PieceColor.BLACK -> when (piece.type) {
            PieceType.PAWN -> "♟"
            PieceType.KNIGHT -> "♞"
            PieceType.BISHOP -> "♝"
            PieceType.ROOK -> "♜"
            PieceType.QUEEN -> "♛"
            PieceType.KING -> "♚"
        }
    }

    Box(
        modifier = Modifier
            .pointerInput(Unit) {}
            .fillMaxSize()
    ) {
        // Offset mapping to move piece inside canvas coordinates
        val left = with(density) { offset.x.toDp() }
        val top = with(density) { offset.y.toDp() }

        Box(
            modifier = Modifier
                .padding(start = left, top = top)
                .size(sizeDp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = unicodeChar,
                fontSize = (sizeDp.value * 0.72f).sp,
                color = if (piece.color == PieceColor.WHITE) Color.White else Color.Black,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = (sizeDp.value * 0.08f).dp)
            )
        }
    }
}

// Convert absolute pointer coordinates to board matrix squares
private fun offsetToBoardSquare(offset: Offset, squareSizePx: Float, isFlipped: Boolean): Square {
    var f = (offset.x / squareSizePx).toInt().coerceIn(0, 7)
    var r = (offset.y / squareSizePx).toInt().coerceIn(0, 7)
    
    // Reverse coordinates mapping if board is rotated around Black's side
    if (isFlipped) {
        f = 7 - f
        r = 7 - r
    }
    
    // Note: Chess rank index 0 represents Rank 8 from the top down visually on coordinates
    return Square(file = f, rank = 7 - r)
}

// Translate structural model square coordinates to absolute offsets
private fun boardSquareToOffset(square: Square, squareSizePx: Float, isFlipped: Boolean): Offset {
    var col = square.file
    var row = 7 - square.rank // Visual top starts at Rank 8

    if (isFlipped) {
        col = 7 - col
        row = 7 - row
    }

    return Offset(
        x = col * squareSizePx,
        y = row * squareSizePx
    )
}

private fun Arrangement_Normal(): Arrangement_RowOrColumn = androidx.compose.foundation.layout.Arrangement.Start
private fun Arrangement_Reverse(): Arrangement_RowOrColumn = androidx.compose.foundation.layout.Arrangement.End

typealias Arrangement_RowOrColumn = androidx.compose.foundation.layout.Arrangement.Horizontal
